ELEVATING TOTS CANADIAN SCHOOL — NETLIFY + DECAP CMS READY

This ZIP is prepared for a GitHub-connected Netlify site.

CMS panel:
https://elevatingtots.com/admin/

What the CMS can manage:
• Home banner badge text
• Home banner heading
• Home banner description
• Home banner image
• School gallery photos
• Gallery captions

IMPORTANT:
The website must be deployed from the GitHub repository connected to Netlify. A drag-and-drop ZIP deployment alone will not let Decap CMS commit changes back to GitHub.

NETLIFY SETUP:
1. Upload these files to your GitHub repository on the main branch.
2. In Netlify, connect the site to that GitHub repository and deploy the main branch.
3. In Netlify, enable Identity.
4. Set registration to Invite only.
5. Enable Git Gateway under Identity/Services.
6. Invite your admin email.
7. Open /admin/ and log in.
8. Edit Website Settings and publish.

The public website reads:
• content/site.json
• content/gallery.json

Uploaded CMS images are stored in:
images/uploads/

NOTE:
Do not delete admin/config.yml or admin/index.html. They are required for the CMS.
